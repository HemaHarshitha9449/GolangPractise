package main

import "fmt"

var Out int = 45

const ZI int = 1000

func main() {
	var x int = 24
	fmt.Println(x)
	fmt.Printf("The type of x is:%T\n", x)
	fmt.Printf("The value of x is:%v\n", x)
	var name string = "Harshitha"
	fmt.Println(name)
	var check bool = true
	fmt.Println(check)
	y := 2
	fmt.Println(y)
	fmt.Println(Out)
	fmt.Println(ZI)
}
